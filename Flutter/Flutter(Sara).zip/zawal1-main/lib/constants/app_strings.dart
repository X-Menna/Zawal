/// 📝 النصوص الثابتة في كل الشاشات
class AppStrings {
  static const String appName = "Zawal";
  static const String welcomeTitle = "Explore the world, one trip at a time";
  static const String welcomeSubtitle = "Your next adventure starts here.";
  static const String welcome = "Welcome Back!";
  static const String login = "Login";
  static const String signup = "Sign Up";
}
