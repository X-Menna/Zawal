/// 📏 مسافات padding والـ radius الموحدة
class AppDimensions {
  static const double padding = 16.0;
  static const double radius = 12.0;
}
